# Exercice dirigé: Table

## Ecrire le code HTML de la table
* Utiliser le rechercher/remplacer pour aller plus rapidement
* Par exemple en remplaçant le caractère "Tabulation" par "</td><td>"


## Couleurs
* Bordure des TD: #ddd
* Bordure inférieur des entêtes et inférieur du pied: #999
